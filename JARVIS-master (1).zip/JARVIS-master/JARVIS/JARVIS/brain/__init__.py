"""Brain components that plan, route, and personalize assistant behavior."""
