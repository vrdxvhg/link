"""Automation modules for workflows, scheduled actions, and external tools."""
