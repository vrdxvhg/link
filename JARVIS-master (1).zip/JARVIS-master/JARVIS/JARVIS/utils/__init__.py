"""Utility modules shared across the JARVIS runtime."""
