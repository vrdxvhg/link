"""Voice input, wake word detection, and speech synthesis modules."""
