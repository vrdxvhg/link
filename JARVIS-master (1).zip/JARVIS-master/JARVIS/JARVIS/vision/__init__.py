"""Vision pipeline package for screen analysis."""
