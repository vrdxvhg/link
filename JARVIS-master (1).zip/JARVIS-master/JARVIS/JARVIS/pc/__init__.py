"""PC control integrations for future desktop automation."""
