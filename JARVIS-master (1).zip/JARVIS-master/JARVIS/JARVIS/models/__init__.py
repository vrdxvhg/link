"""Shared model contracts, types, and provider implementations."""
