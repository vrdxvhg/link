"""Memory backends and persistence adapters."""
