"""JARVIS package.

This package is the foundation for a modular AI operating system. The public
modules are intentionally small so future capabilities can plug in without
coupling themselves to the conversation loop.
"""

__version__ = "0.1.0"
