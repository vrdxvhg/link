"""User interface adapters for future desktop, mobile, and web clients."""
