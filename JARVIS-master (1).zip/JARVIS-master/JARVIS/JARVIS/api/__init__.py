"""API adapters for future HTTP, WebSocket, and app integrations."""
