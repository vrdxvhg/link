"""Skill plugin architecture for future assistant capabilities."""
