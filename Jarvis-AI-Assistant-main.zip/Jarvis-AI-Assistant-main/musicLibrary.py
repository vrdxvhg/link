
music={
    "dil dil pakistan" :"https://www.youtube.com/watch?v=X7nrQLFnxbU&list=RDX7nrQLFnxbU&start_radio=1" ,
    "pakistan zindabad":"https://www.youtube.com/watch?v=MjxGwfa5lxw&list=RDMjxGwfa5lxw&start_radio=1",
    "mere watan ": "https://www.youtube.com/watch?v=xZ8tNY607nc&list=RDxZ8tNY607nc&start_radio=1",
    "hamara pakistan": "https://www.youtube.com/watch?v=euVogfXKn8w&list=RDeuVogfXKn8w&start_radio=1"




}

