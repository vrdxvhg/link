# Source Code Availability

The complete J.A.R.V.I.S. source code is hosted externally because it exceeds GitHub's file size limits.

You can access and download the full project here:

🔗 **Google Drive:**
(https://drive.google.com/file/d/16cuuwYxwhQVrRSSK8Hw0UTqnVbf4PoHD/view?usp=drive_link)

The repository still contains the project documentation, screenshots, and other supporting files.

Thank you for visiting the project!
