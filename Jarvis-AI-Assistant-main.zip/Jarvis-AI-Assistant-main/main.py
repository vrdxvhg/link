import pyttsx3

import webbrowser
import speech_recognition as sr
import musicLibrary
from ollama import chat
import sys
import time

messages= [
            {
                "role":"system",
                "content": """You are Jarvis, a very helpful AI assistant
                Rules:
                1-keep your answers short and clear.
                2- reply in the same language as the user.
                3- be polite and friendly.
                4- do not introduce yourself unless user asks who are you.
                5-if you do not know something, say you are  not sure instead of making up an answer
                """
                              
            },          
           
        ]
def speak(text):
    engine=pyttsx3.init()
    engine.say(text)
    engine.runAndWait()
    engine.stop()

def askAI(prompt):

    messages.append(
        {
            "role":"user" ,
            "content": prompt
        }
    )
    response= chat(
        model= "llama3" ,
        messages=messages
    
    )
    messages.append(
        {
        "role":"assistant",
        "content":response.message.content
        }
    )
    return response.message.content
    



def  processCommand(c):
    if "open google" in c.lower():
        webbrowser.open("https://www.google.com/")
        speak("opening Google")

    elif"open facebook" in c.lower():
        webbrowser.open("https://www.facebook.com/")
        speak("opening Facebook")
    elif"open youtube" in c.lower():
        webbrowser.open("https://www.youtube.com/")
        speak("opening Youtube")
    elif"open ranchers " in c.lower():
        webbrowser.open("https://rancherscafe.com/")
        speak("opening Google")

    elif "exit" in c.lower():
        speak("Good bye Madeeeha, Keep it up")
        sys.exit()


    elif c.lower().startswith("play"):
        speak("Playing Song")
        # split what we say on base of song and link as shown below
        song = c.lower().replace("play "," ").strip()
        if song in musicLibrary.music:
            link = musicLibrary.music[song]
            webbrowser.open(link)

        else:
            print("song not found")

    else:
            answer=askAI(c)
            print(c)
            print(answer)
            speak(answer)
    
   

if __name__=="__main__":

    speak("Initializing Jarvis Your personal assistant.....")
    while True:
        #listen for wake keyword "Jarvis"

        # obtain audio from the microphone
        r = sr.Recognizer()

        print("recognizing..")
        
        # recognize speech 
        try:
            with sr.Microphone() as source:
                print("Listenting")
                audio = r.listen(source,timeout=5,phrase_time_limit=3)
                word= r.recognize_google(audio)
                
                # setting wake word, Jarvis
                if "jarvis" in word.lower():

                    speak("Ya jarvis here")
                    print("Ya jarvis here")
                
                    with sr.Microphone() as source:
                        print("jarvis Activated...")
                       
                        audio = r.listen(source)
                    command= r.recognize_google(audio)
# calling function for processing these commands
                    processCommand(command)

                    print(command)
        except sr.UnknownValueError:
            print("jarvis could not understand audio")
        except sr.RequestError as e:
            print("Jarvis error; {0}".format(e))

        except sr.WaitTimeoutError:
          print("No speech detected.")