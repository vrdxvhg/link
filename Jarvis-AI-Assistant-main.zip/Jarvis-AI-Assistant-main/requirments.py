# ============================================================
# J.A.R.V.I.S. (Just A Responsive Voice Interactive System)
# Setup & Requirements Notes
# Developed by: Madiha Asghar
# ============================================================

# ------------------------------------------------------------
# Recommended Python Version
# ------------------------------------------------------------
# Python 3.11.x
# (Project tested on Python 3.11)

# ------------------------------------------------------------
# Create Virtual Environment
# ------------------------------------------------------------
# python -m venv venv

# Activate (Windows)
# venv\Scripts\activate

# ------------------------------------------------------------
# Install Required Libraries
# ------------------------------------------------------------

# pip install pyttsx3
# pip install SpeechRecognition
# pip install PyAudio
# pip install ollama

# OR install everything together

# pip install pyttsx3 SpeechRecognition PyAudio ollama

# ------------------------------------------------------------
# If PyAudio Installation Fails
# ------------------------------------------------------------

# pip install pipwin
# pipwin install pyaudio

# OR

# pip install PyAudio

# ------------------------------------------------------------
# Ollama Setup
# ------------------------------------------------------------

# Download Ollama:
# https://ollama.com

# Pull Llama 3 Model

# ollama pull llama3

# Check Installed Models

# ollama list

# Start Ollama Server (if required)

# ollama serve

# Test Model

# ollama run llama3

# ------------------------------------------------------------
# Run Project
# ------------------------------------------------------------

# python main.py

# ------------------------------------------------------------
# Libraries Used
# ------------------------------------------------------------

# pyttsx3               -> Text to Speech
# SpeechRecognition     -> Voice Recognition
# PyAudio               -> Microphone Input
# ollama                -> Local LLM Integration

# ------------------------------------------------------------
# Built-in Python Modules (No Installation Required)
# ------------------------------------------------------------

# webbrowser
# sys
# time

# ------------------------------------------------------------
# Project Features
# ------------------------------------------------------------

# Wake Word Detection
# Speech Recognition
# Local LLM (Llama 3)
# Conversation Memory
# Voice Responses
# Browser Automation
# Music Playback
# Voice Commands
# Prompt Engineering

# ------------------------------------------------------------
# Voice Commands
# ------------------------------------------------------------

# Jarvis
# Open Google
# Open YouTube
# Open Facebook
# Open Ranchers
# Play <Song Name>
# Exit

# ------------------------------------------------------------
# Notes
# ------------------------------------------------------------

# Internet is only required for Google Speech Recognition.
# Llama 3 runs locally using Ollama.
# Make sure your microphone is connected before running.
# Keep Ollama running before starting JARVIS.

# ============================================================
# End of File
# ============================================================