"""Conversation repository — implements the Storage protocol for SQLite."""

from __future__ import annotations

import json
import logging
from datetime import UTC
from typing import TYPE_CHECKING

from dax.core.models import (
    ChannelType,
    Conversation,
    Language,
    Message,
    MessageRole,
)

if TYPE_CHECKING:
    from datetime import datetime

    import aiosqlite

    from dax.storage.database import Database

logger = logging.getLogger(__name__)

_MAX_QUERY_LIMIT = 500
_MAX_CONVERSATION_MESSAGES = 10_000


def _bounded_limit(limit: int) -> int:
    return max(0, min(limit, _MAX_QUERY_LIMIT))


def _parse_datetime(value: str) -> datetime:
    """Parse an ISO format datetime string."""
    from datetime import datetime

    dt = datetime.fromisoformat(value)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt


class ConversationRepository:
    """SQLite-backed conversation storage.

    Implements the Storage protocol defined in core/ports.py.
    """

    def __init__(self, database: Database) -> None:
        self._db = database

    async def start(self) -> None:
        """No-op — database lifecycle is managed separately."""

    async def stop(self) -> None:
        """No-op — database lifecycle is managed separately."""

    async def save_conversation(self, conversation: Conversation) -> None:
        """Persist a conversation and all its messages."""
        async with self._db.transaction() as conn:
            await conn.execute(
                """
            INSERT INTO conversations
                (id, channel, session_key, title, created_at, updated_at)
            VALUES (?, ?, ?, COALESCE(
                (SELECT NULLIF(title, '') FROM conversations WHERE id = ?),
                ''
            ), ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                channel = excluded.channel,
                session_key = excluded.session_key,
                created_at = excluded.created_at,
                updated_at = excluded.updated_at
            """,
                (
                    conversation.id,
                    conversation.channel.value,
                    conversation.session_key,
                    conversation.id,
                    conversation.created_at.isoformat(),
                    conversation.updated_at.isoformat(),
                ),
            )

            for msg in conversation.messages:
                await conn.execute(
                    """
                INSERT OR REPLACE INTO messages
                    (id, conversation_id, role, content, channel, language, timestamp, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                    (
                        msg.id,
                        conversation.id,
                        msg.role.value,
                        msg.content,
                        msg.channel.value,
                        msg.language.value,
                        msg.timestamp.isoformat(),
                        json.dumps(msg.metadata, default=str),
                    ),
                )

            # Auto-set title from first user message if still empty.
            await conn.execute(
                """
            UPDATE conversations
            SET title = (
                SELECT SUBSTR(content, 1, 60)
                FROM messages
                WHERE conversation_id = ? AND role = 'user'
                ORDER BY timestamp
                LIMIT 1
            )
            WHERE id = ? AND (title IS NULL OR title = '')
            """,
                (conversation.id, conversation.id),
            )

        logger.debug(
            "Saved conversation %s with %d messages",
            conversation.id,
            len(conversation.messages),
        )

    async def get_conversation(self, conversation_id: str) -> Conversation | None:
        """Retrieve a conversation by ID, including all messages."""
        async with self._db.read() as conn:
            return await self._load_conversation(conn, conversation_id)

    @staticmethod
    async def _load_conversation(
        conn: aiosqlite.Connection, conversation_id: str
    ) -> Conversation | None:
        cursor = await conn.execute(
            "SELECT * FROM conversations WHERE id = ?",
            (conversation_id,),
        )
        row = await cursor.fetchone()
        if row is None:
            return None

        conversation = Conversation(
            id=row["id"],
            channel=ChannelType(row["channel"]),
            session_key=row["session_key"],
            created_at=_parse_datetime(row["created_at"]),
            updated_at=_parse_datetime(row["updated_at"]),
        )

        msg_cursor = await conn.execute(
            "SELECT * FROM ("
            "SELECT * FROM messages WHERE conversation_id = ? "
            "ORDER BY timestamp DESC, id DESC LIMIT ?"
            ") ORDER BY timestamp, id",
            (conversation_id, _MAX_CONVERSATION_MESSAGES),
        )
        rows = await msg_cursor.fetchall()

        for msg_row in rows:
            message = Message(
                id=msg_row["id"],
                role=MessageRole(msg_row["role"]),
                content=msg_row["content"],
                channel=ChannelType(msg_row["channel"]),
                language=Language(msg_row["language"]),
                timestamp=_parse_datetime(msg_row["timestamp"]),
                metadata=json.loads(msg_row["metadata"]),
            )
            conversation.messages.append(message)

        return conversation

    async def get_or_create_conversation(
        self,
        channel: ChannelType,
        session_key: str,
    ) -> Conversation:
        """Return the existing conversation for (channel, session_key), or a new one.

        A new conversation is NOT persisted until the next ``save_conversation``
        — callers append messages and save once per turn.
        """
        async with self._db.read() as conn:
            cursor = await conn.execute(
                """
                SELECT id FROM conversations
                WHERE channel = ? AND session_key = ?
                ORDER BY updated_at DESC
                LIMIT 1
                """,
                (channel.value, session_key),
            )
            row = await cursor.fetchone()
            if row is not None:
                existing = await self._load_conversation(conn, row["id"])
                if existing is not None:
                    return existing

        return Conversation(channel=channel, session_key=session_key)

    async def log_tool_execution(
        self,
        *,
        server_name: str,
        tool_name: str,
        arguments: dict[str, object],
        status: str,
    ) -> None:
        """Append a tool-execution record to the audit log."""
        from datetime import datetime

        async with self._db.transaction() as conn:
            await conn.execute(
                """
            INSERT INTO tool_audit (timestamp, server_name, tool_name, arguments, status)
            VALUES (?, ?, ?, ?, ?)
            """,
                (
                    datetime.now(UTC).isoformat(),
                    server_name,
                    tool_name,
                    json.dumps(arguments, default=str),
                    status,
                ),
            )

    async def get_tool_audit(self, limit: int = 50) -> list[dict[str, object]]:
        """Return the most recent tool-audit entries (newest first)."""
        async with self._db.read() as conn:
            cursor = await conn.execute(
                """
                SELECT timestamp, server_name, tool_name, arguments, status
                FROM tool_audit ORDER BY id DESC LIMIT ?
                """,
                (_bounded_limit(limit),),
            )
            rows = await cursor.fetchall()
        return [
            {
                "timestamp": r["timestamp"],
                "server_name": r["server_name"],
                "tool_name": r["tool_name"],
                "arguments": json.loads(r["arguments"]),
                "status": r["status"],
            }
            for r in rows
        ]

    async def list_conversations(
        self,
        channel: str,
        limit: int = 50,
    ) -> list[dict[str, object]]:
        """Return a lightweight summary list of conversations for a channel.

        Does NOT load full message objects — suitable for sidebar listings.
        """
        async with self._db.read() as conn:
            cursor = await conn.execute(
                """
            SELECT
                c.id,
                c.session_key,
                c.title,
                c.created_at,
                c.updated_at,
                (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id) AS message_count,
                (SELECT content FROM messages
                 WHERE conversation_id = c.id AND role = 'user'
                 ORDER BY timestamp LIMIT 1) AS preview
            FROM conversations c
            WHERE c.channel = ?
            ORDER BY c.updated_at DESC
            LIMIT ?
            """,
                (channel, _bounded_limit(limit)),
            )
            rows = await cursor.fetchall()
        return [
            {
                "id": r["id"],
                "session_key": r["session_key"],
                "title": r["title"] or r["preview"] or "New conversation",
                "preview": (r["preview"] or "")[:80],
                "updated_at": r["updated_at"],
                "message_count": r["message_count"],
            }
            for r in rows
        ]

    async def delete_conversation(self, conversation_id: str) -> None:
        """Delete a conversation and all its messages (cascade)."""
        async with self._db.transaction() as conn:
            await conn.execute(
                "DELETE FROM conversations WHERE id = ?",
                (conversation_id,),
            )
        logger.debug("Deleted conversation %s", conversation_id)

    async def get_recent_conversations(
        self,
        channel: str,
        limit: int = 5,
    ) -> list[Conversation]:
        """Retrieve the most recent conversations for a channel."""
        async with self._db.read() as conn:
            cursor = await conn.execute(
                """
                SELECT id FROM conversations
                WHERE channel = ?
                ORDER BY updated_at DESC
                LIMIT ?
                """,
                (channel, _bounded_limit(limit)),
            )
            rows = await cursor.fetchall()

            conversations: list[Conversation] = []
            for row in rows:
                conv = await self._load_conversation(conn, row["id"])
                if conv is not None:
                    conversations.append(conv)

        return conversations
