"""Single-user authentication for the web UI and API.

Dax is a personal assistant: one user, one password. We store an argon2 hash
of the password (never the password itself) and hand out signed, expiring
session cookies on login.

Secrets come from the environment (see ``.env``):
  - ``DAX_SECURITY__PASSWORD_HASH``   argon2 hash of the login password
  - ``DAX_SECURITY__SESSION_SECRET``  random string used to sign cookies

Generate a password hash from the command line::

    python -m dax.web.auth "my-super-secret-password"
"""

from __future__ import annotations

import asyncio
import logging
import secrets
import time
from dataclasses import dataclass
from math import ceil
from typing import TYPE_CHECKING

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerifyMismatchError
from fastapi import HTTPException, Request, status
from itsdangerous import BadSignature, SignatureExpired, URLSafeTimedSerializer

if TYPE_CHECKING:
    from collections.abc import Callable

    from fastapi import Response, WebSocket

    from dax.capabilities.hub import CapabilityHub
    from dax.core.config import SecurityConfig
    from dax.storage.devices import DeviceRegistry

logger = logging.getLogger(__name__)

_hasher = PasswordHasher()

# Salt namespaces the signer so a session secret reused elsewhere can't be
# cross-used to forge Dax sessions.
_SIGNER_SALT = "dax.session.v1"
_SESSION_SUBJECT = "dax-user"

# Device access tokens are signed under a different salt, so a browser session
# token can never be presented as a device token (or the reverse) even though
# both derive from the same session secret. Their lifetimes differ by orders of
# magnitude, and that difference has to be unforgeable.
_DEVICE_SALT = "dax.device.v1"
_CAPABILITY_NODE_SALT = "dax.capability-node.v1"
_CAPABILITY_NODE_AUDIENCE = "dax-capability-node"


@dataclass(slots=True)
class _AttemptBucket:
    count: int
    expires_at: float


class AttemptLimiter:
    """Small in-memory fixed-window limiter with bounded client state."""

    def __init__(
        self,
        *,
        max_client_keys: int = 1024,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._max_client_keys = max(1, max_client_keys)
        self._clock = clock
        self._clients: dict[tuple[str, str], _AttemptBucket] = {}
        self._global: dict[str, _AttemptBucket] = {}

    def check(
        self,
        scope: str,
        client_key: str,
        *,
        client_limit: int,
        global_limit: int,
        window_seconds: int = 60,
    ) -> int | None:
        """Consume an attempt, returning retry seconds when it is limited."""
        now = self._clock()
        self._prune(now)

        global_bucket = self._global.get(scope)
        if global_bucket is not None and global_bucket.count >= global_limit:
            return max(1, ceil(global_bucket.expires_at - now))

        key = (scope, client_key)
        client_bucket = self._clients.get(key)
        if client_bucket is not None and client_bucket.count >= client_limit:
            return max(1, ceil(client_bucket.expires_at - now))

        expires_at = now + window_seconds
        if global_bucket is None:
            global_bucket = _AttemptBucket(0, expires_at)
            self._global[scope] = global_bucket
        global_bucket.count += 1

        if client_bucket is None:
            if len(self._clients) >= self._max_client_keys:
                oldest = min(self._clients, key=lambda item: self._clients[item].expires_at)
                del self._clients[oldest]
            client_bucket = _AttemptBucket(0, expires_at)
            self._clients[key] = client_bucket
        client_bucket.count += 1
        return None

    def _prune(self, now: float) -> None:
        self._clients = {
            key: bucket for key, bucket in self._clients.items() if bucket.expires_at > now
        }
        self._global = {
            scope: bucket for scope, bucket in self._global.items() if bucket.expires_at > now
        }

    @property
    def client_key_count(self) -> int:
        self._prune(self._clock())
        return len(self._clients)


def hash_password(password: str) -> str:
    """Return an argon2id hash of ``password``."""
    return _hasher.hash(password)


def verify_password(password_hash: str, password: str) -> bool:
    """Check ``password`` against a stored argon2 hash."""
    if not password_hash:
        return False
    try:
        return _hasher.verify(password_hash, password)
    except (VerifyMismatchError, InvalidHashError):
        return False


class AuthManager:
    """Validates logins and issues/validates signed session tokens.

    Lives on ``app.state.auth`` and is consulted by the ``require_auth``
    dependency and the WebSocket handshake.
    """

    def __init__(self, config: SecurityConfig) -> None:
        self._enabled = config.auth_enabled
        self._password_hash = config.password_hash
        self._ttl_seconds = max(1, config.session_ttl_hours) * 3600
        self.cookie_name = config.cookie_name
        self.cookie_secure = config.cookie_secure

        secret = config.session_secret
        if not secret:
            # Ephemeral secret: logins work, but sessions don't survive a
            # restart. Fine for first run; warn so the user sets a real one.
            secret = secrets.token_urlsafe(48)
            if self._enabled:
                logger.warning(
                    "No DAX_SECURITY__SESSION_SECRET set — using an ephemeral "
                    "secret; sessions will be invalidated on restart."
                )
        self._serializer = URLSafeTimedSerializer(secret, salt=_SIGNER_SALT)
        self._device_serializer = URLSafeTimedSerializer(secret, salt=_DEVICE_SALT)
        self._capability_serializer = URLSafeTimedSerializer(
            secret, salt=_CAPABILITY_NODE_SALT
        )
        self._device_ttl_seconds = max(60, config.device_token_ttl_minutes * 60)
        self._devices: DeviceRegistry | None = None
        self.capability_hub: CapabilityHub | None = None
        self.attempt_limiter = AttemptLimiter()
        self.setup_lock = asyncio.Lock()

        if self._enabled and not self._password_hash:
            logger.warning(
                "Auth is enabled but no DAX_SECURITY__PASSWORD_HASH is set — "
                "login is impossible. Generate one with "
                "`python -m dax.web.auth <password>`."
            )

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def configured(self) -> bool:
        """True when a password is set (login is possible)."""
        return bool(self._password_hash)

    def verify_login(self, password: str) -> bool:
        return verify_password(self._password_hash, password)

    def attach_devices(self, devices: DeviceRegistry) -> None:
        """Wire the enrolled-device registry used to validate device tokens.

        Optional: with no registry attached the manager behaves exactly as it
        did before device enrolment existed, and device tokens are rejected.
        """
        self._devices = devices

    def attach_capability_hub(self, hub: CapabilityHub) -> None:
        self.capability_hub = hub

    @property
    def devices(self) -> DeviceRegistry | None:
        return self._devices

    @property
    def device_token_ttl_seconds(self) -> int:
        return self._device_ttl_seconds

    def issue_token(self) -> str:
        return self._serializer.dumps({"sub": _SESSION_SUBJECT})

    def issue_device_token(self, device_id: str) -> str:
        """Mint a short-lived access token for an enrolled device."""
        from dax.storage.devices import CLIENT_KIND

        if self._devices is not None and not self._devices.is_active_kind(
            device_id, CLIENT_KIND
        ):
            raise ValueError("Device is not an active client")
        return self._device_serializer.dumps({"sub": device_id})

    def issue_capability_token(self, device_id: str) -> str:
        from dax.storage.devices import CAPABILITY_NODE_KIND

        if self._devices is None or not self._devices.is_active_kind(
            device_id, CAPABILITY_NODE_KIND
        ):
            raise ValueError("Device is not an active capability node")
        return self._capability_serializer.dumps(
            {"sub": device_id, "aud": _CAPABILITY_NODE_AUDIENCE}
        )

    def validate_token(self, token: str | None) -> bool:
        """True when *token* is a live user session or a live device token."""
        return self.is_session_token(token) or self.device_from_token(token) is not None

    def is_session_token(self, token: str | None) -> bool:
        """True only for a live browser/desktop session token."""
        if not token:
            return False
        try:
            payload = self._serializer.loads(token, max_age=self._ttl_seconds)
        except (BadSignature, SignatureExpired):
            return False
        return isinstance(payload, dict) and payload.get("sub") == _SESSION_SUBJECT

    def device_from_token(self, token: str | None) -> str | None:
        """Return the device id for a valid device token, else None.

        Revocation is enforced here rather than at issue time: a token minted
        before a phone was lost must stop working the moment it is revoked,
        not when it eventually expires.
        """
        if not token or self._devices is None:
            return None
        try:
            payload = self._device_serializer.loads(token, max_age=self._device_ttl_seconds)
        except (BadSignature, SignatureExpired):
            return None
        device_id = payload.get("sub") if isinstance(payload, dict) else None
        if not isinstance(device_id, str) or not device_id:
            return None
        from dax.storage.devices import CLIENT_KIND

        if not self._devices.is_active_kind(device_id, CLIENT_KIND):
            logger.info("Rejected token for revoked or unknown device %s", device_id)
            return None
        return device_id

    def capability_node_from_token(self, token: str | None) -> str | None:
        if not token or self._devices is None:
            return None
        try:
            payload = self._capability_serializer.loads(
                token, max_age=self._device_ttl_seconds
            )
        except (BadSignature, SignatureExpired):
            return None
        if not isinstance(payload, dict) or payload.get("aud") != _CAPABILITY_NODE_AUDIENCE:
            return None
        node_id = payload.get("sub")
        if not isinstance(node_id, str):
            return None
        from dax.storage.devices import CAPABILITY_NODE_KIND

        return (
            node_id
            if self._devices.is_active_kind(node_id, CAPABILITY_NODE_KIND)
            else None
        )

    def authenticate_capability_websocket(self, websocket: WebSocket) -> str | None:
        candidates = [
            websocket.query_params.get("token"),
            self._bearer_token(websocket.headers.get("authorization")),
        ]
        for token in candidates:
            node_id = self.capability_node_from_token(token)
            if node_id is not None:
                return node_id
        return None

    def set_cookie(self, response: Response, token: str) -> None:
        response.set_cookie(
            key=self.cookie_name,
            value=token,
            max_age=self._ttl_seconds,
            httponly=True,
            samesite="lax",
            secure=self.cookie_secure,
            path="/",
        )

    def clear_cookie(self, response: Response) -> None:
        response.delete_cookie(key=self.cookie_name, path="/")

    # -- request helpers --

    @staticmethod
    def _bearer_token(header: str | None) -> str | None:
        """Extract the token from an ``Authorization: Bearer <token>`` header."""
        if not header:
            return None
        scheme, _, value = header.partition(" ")
        if scheme.lower() != "bearer":
            return None
        return value.strip() or None

    def _token_candidates(self, request: Request) -> list[str]:
        """Every credential the request offers, in preference order.

        The browser SPA sends a cookie; the desktop client sends a bearer
        token. Both are collected so a stale cookie can't shadow a valid
        bearer token (or vice versa) — ``is_authenticated`` accepts if *any*
        candidate validates.
        """
        candidates = [
            request.cookies.get(self.cookie_name),
            self._bearer_token(request.headers.get("authorization")),
        ]
        return [token for token in candidates if token]

    def _token_from_headers(self, request: Request) -> str | None:
        """First offered credential, or ``None``. Kept for compatibility."""
        candidates = self._token_candidates(request)
        return candidates[0] if candidates else None

    def is_authenticated(self, request: Request) -> bool:
        if not self._enabled:
            return True
        return any(self.validate_token(token) for token in self._token_candidates(request))

    def is_session_authenticated(self, request: Request) -> bool:
        """Accept session cookies/bearers, but never enrolled-device tokens."""
        if not self._enabled:
            return True
        return any(self.is_session_token(token) for token in self._token_candidates(request))

    def requesting_device(self, request: Request) -> str | None:
        """The enrolled device behind *request*, if it is a device at all.

        A user session deliberately yields None. Sessions belong to the human,
        not to a piece of hardware, and anything scoped to a specific device
        needs to know which one.
        """
        for token in self._token_candidates(request):
            device_id = self.device_from_token(token)
            if device_id is not None:
                return device_id
        return None

    def authenticate_websocket(self, websocket: WebSocket) -> bool:
        """Validate a WebSocket via cookie, ``?token=``, or bearer header."""
        if not self._enabled:
            return True
        candidates = [
            websocket.cookies.get(self.cookie_name),
            websocket.query_params.get("token"),
            self._bearer_token(websocket.headers.get("authorization")),
        ]
        return any(self.validate_token(token) for token in candidates if token)


def require_auth(request: Request) -> None:
    """FastAPI dependency that rejects unauthenticated requests with 401."""
    auth: AuthManager | None = getattr(request.app.state, "auth", None)
    if auth is None:
        # Auth not wired (shouldn't happen) — fail closed.
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Auth not configured")
    if not auth.is_authenticated(request):
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED,
            "Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )


def require_session(request: Request) -> None:
    """Reject requests that do not carry a user session credential."""
    auth: AuthManager | None = getattr(request.app.state, "auth", None)
    if auth is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Auth not configured")
    if not auth.is_session_authenticated(request):
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED,
            "Session authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )


def _main() -> None:
    import sys

    if len(sys.argv) != 2:
        print("Usage: python -m dax.web.auth <password>", file=sys.stderr)
        raise SystemExit(2)
    print(hash_password(sys.argv[1]))


if __name__ == "__main__":
    _main()
