"""Application bootstrap and lifecycle management.

Wires all components together via dependency injection and manages
the startup/shutdown sequence. Runs uvicorn embedded in the asyncio loop.
"""

from __future__ import annotations

import asyncio
import logging
import signal
import uuid
from typing import TYPE_CHECKING, Any

import structlog
import uvicorn

from dax.capabilities import CapabilityHub
from dax.capabilities.tickets import public_key_for, signing_key
from dax.channels.telegram_channel import TelegramChannel
from dax.channels.voice_channel import VoiceChannel
from dax.channels.web_channel import WebChannel
from dax.channels.whatsapp_channel import WhatsAppChannel
from dax.core.config import DaxConfig, load_config
from dax.core.logbuffer import LogBuffer
from dax.core.policy import ToolPolicy
from dax.core.shell_allow import ShellAllowlist
from dax.core.voice_events import VoiceEventHub
from dax.llm.factory import build_router
from dax.mcp.manager import MCPManager
from dax.orchestrator.agent import Agent
from dax.orchestrator.approval import ApprovalManager
from dax.orchestrator.bus import MessageBus
from dax.orchestrator.dispatcher import Dispatcher
from dax.storage.database import Database
from dax.storage.devices import DeviceRegistry
from dax.storage.repository import ConversationRepository
from dax.storage.secrets import SecretStore
from dax.voice.tts_service import TTSService
from dax.web.server import create_app

if TYPE_CHECKING:
    from pathlib import Path

    from dax.voice.pipeline import VoicePipeline

logger = structlog.get_logger(__name__)

_SERVER_INSTANCE_ID_KEY = "DAX_SERVER_INSTANCE_ID"


def _load_server_instance_id(store: SecretStore) -> str:
    """Return the authority identity, creating it in encrypted storage once."""
    instance_id = store.get(_SERVER_INSTANCE_ID_KEY)
    if instance_id is None:
        instance_id = str(uuid.uuid4())
        store.set(_SERVER_INSTANCE_ID_KEY, instance_id)
    return instance_id


def _configure_logging(log_level: str) -> None:
    """Set up structlog with console rendering."""
    level = getattr(logging, log_level.upper(), logging.INFO)
    logging.basicConfig(format="%(message)s", level=level)
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.StackInfoRenderer(),
            structlog.dev.ConsoleRenderer(),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )


class DaxApp:
    """Main application — orchestrates all components.

    Usage:
        app = DaxApp.from_config_path(config_path)
        await app.run()
    """

    def __init__(self, config: DaxConfig, config_path: Path | None = None) -> None:
        self._config = config
        self._shutdown_event = asyncio.Event()

        # Capture stdlib logs into a ring buffer for the web Logs viewer.
        self._log_buffer = LogBuffer()
        logging.getLogger().addHandler(self._log_buffer)

        # Core components
        self._bus = MessageBus()
        self._database = Database(config.storage.database_path)
        self._repository = ConversationRepository(self._database)

        # Encrypted secret store (replaces .env as the source of truth).
        self._secrets = SecretStore(config.storage.database_path)
        self._server_instance_id = _load_server_instance_id(self._secrets)
        from dax.web.routes.oauth import configure_oauth_store

        configure_oauth_store(self._secrets)

        # LLM router — decoupled, multi-provider (official SDKs). The default
        # provider plus the configured fallback chain, all behind the
        # LLMProvider port.
        self._llm = build_router(config.llm)

        # MCP server manager
        self._mcp = MCPManager(config.mcp)

        # Tool execution policy + human-in-the-loop confirmation gate.
        self._policy = ToolPolicy.from_config(config.tools.policy)
        self._approval = ApprovalManager(timeout_seconds=config.tools.confirm_timeout_seconds)

        # Authoritative shell-command allowlist. Mutations update the encrypted
        # configuration document in SQLite.
        self._shell_allow = ShellAllowlist(config.tools.shell_allow)
        self._shell_allow.set_on_change(self._persist_shell_allow)

        # Channels
        self._channels: dict[
            str, VoiceChannel | WebChannel | WhatsAppChannel | TelegramChannel
        ] = {}

        # Voice pipeline (initialized in start() if enabled)
        self._voice_pipeline: VoicePipeline | None = None
        self._tts_service = TTSService(config.voice, config.storage.models_path)
        self._voice_reload_lock = asyncio.Lock()
        # The event hub outlives any individual pipeline: it is owned here so a
        # UI client subscribed to /ws/voice keeps its connection across voice
        # reloads, and can connect at all while voice is disabled.
        self._voice_events = VoiceEventHub()

        # Web
        self._web_app = create_app(
            config=config,
            bus=self._bus,
            server_instance_id=self._server_instance_id,
        )
        self._web_app.state.voice_events = self._voice_events
        self._web_app.state.approval = self._approval
        self._web_app.state.tts_service = self._tts_service
        self._uvicorn_server: uvicorn.Server | None = None

        self._agent: Agent | None = None
        self._dispatcher: Dispatcher | None = None
        self._capability_hub: CapabilityHub | None = None

    @classmethod
    def from_config_path(cls, config_path: Path | None = None) -> DaxApp:
        """Create a DaxApp instance from a config file path."""
        config = load_config(config_path)
        _configure_logging(config.log_level)
        return cls(config)

    @property
    def config(self) -> DaxConfig:
        return self._config

    def _persist_shell_allow(self, commands: list[str]) -> None:
        """Mirror the live shell allowlist into encrypted configuration."""
        from dax.core.config_io import save_encrypted_config

        object.__setattr__(self._config.tools, "shell_allow", list(commands))
        try:
            save_encrypted_config(self._config, self._secrets)
        except Exception:
            logger.exception("Failed to persist shell allowlist")

    async def _persist_config(self) -> None:
        """Write the live config through, off the event loop.

        Encryption plus a SQLite write is not something to do inline on the
        loop that is holding a user's turn open.
        """
        from dax.core.config_io import save_encrypted_config

        await asyncio.to_thread(save_encrypted_config, self._config, self._secrets)

    def set_system_prompt(self, prompt: str) -> None:
        """Apply the configured prompt to the live agent for its next turn."""
        if self._agent is not None:
            self._agent.set_system_prompt(prompt)

    @property
    def web_app(self) -> object:
        """Expose FastAPI app for testing."""
        return self._web_app

    async def start(self) -> None:
        """Initialize all components in dependency order."""
        log = logger.bind(app="dax")
        log.info("Starting Dax Assistant", version="0.1.0", name=self._config.name)

        # 1. Storage
        await self._database.start()
        log.info("Storage ready")

        # Enrolled devices back the short-lived tokens the mobile client uses.
        # Loaded into memory here because token validation runs inside the
        # WebSocket handshake, where awaiting SQLite is not an option.
        self._devices = DeviceRegistry(self._database)
        await self._devices.load()
        self._capability_hub = CapabilityHub(
            self._mcp,
            self._devices,
            self.config.nodes,
            # Deferred: the key is generated the first time something needs it,
            # which may be this call or may be a phone asking for a ticket.
            public_key=lambda: public_key_for(signing_key(self._secrets)),
            voice=self.config.voice,
        )
        if hasattr(self._web_app, "state"):
            auth_manager = getattr(self._web_app.state, "auth", None)
            if auth_manager is not None:
                auth_manager.attach_devices(self._devices)
                auth_manager.attach_capability_hub(self._capability_hub)
            self._web_app.state.devices = self._devices
            self._web_app.state.capability_hub = self._capability_hub
        log.info("Device registry ready", devices=self._devices.count)

        # Deliver live log records to web subscribers on this loop.
        self._log_buffer.bind_loop(asyncio.get_running_loop())
        if hasattr(self._web_app, "state"):
            self._web_app.state.log_buffer = self._log_buffer
            self._web_app.state.tool_policy = self._policy
            # The live shell allowlist the agent consults, so the Commands page
            # can read/edit it.
            self._web_app.state.shell_allow = self._shell_allow
            # Expose the secret store + the app itself so settings endpoints can
            # persist secrets to SQLite and reload live channels (Telegram).
            self._web_app.state.secret_store = self._secrets
            self._web_app.state.dax_app = self

        # 2. Message bus
        self._bus.start()
        log.info("Message bus ready")

        # 3. MCP servers
        await self._mcp.start()
        # Expose manager + repository on web app state for API endpoints.
        if hasattr(self._web_app, "state"):
            self._web_app.state.mcp_manager = self._mcp
            self._web_app.state.repository = self._repository
            # Expose the router so the settings API can rebuild it in place
            # when the LLM config changes (no restart needed).
            self._web_app.state.llm_router = self._llm
        log.info(
            "MCP ready",
            servers=len(self._mcp._clients),
            tools=self._mcp.registry.tool_count,
        )

        # 4. LLM availability check
        llm_available = await self._llm.is_available()
        if llm_available:
            log.info("LLM ready", provider=self._llm.name)
        else:
            log.warning("LLM not available — responses will fail")

        # 5. Channels
        web_channel = WebChannel()
        await web_channel.start()
        self._channels["web"] = web_channel

        if self._config.whatsapp.enabled:
            wa_channel = WhatsAppChannel(self._config.whatsapp)
            await wa_channel.start()
            self._channels["whatsapp"] = wa_channel

        if self._config.telegram.enabled:
            tg_channel = TelegramChannel(self._config.telegram, self._bus)
            await tg_channel.start()
            self._channels["telegram"] = tg_channel

        # Voice channel (always registered so dispatcher can route to it)
        if self._config.voice.enabled:
            voice_channel = VoiceChannel()
            await voice_channel.start()
            self._channels["voice"] = voice_channel

        log.info("Channels ready", channels=list(self._channels.keys()))

        # 6. Agent
        self._agent = Agent(
            bus=self._bus,
            llm=self._llm,
            tools=self._mcp,
            storage=self._repository,
            policy=self._policy,
            approval=self._approval,
            shell_allow=self._shell_allow,
            max_tools=self._config.llm.max_tools,
            max_tool_iterations=self._config.llm.max_tool_iterations,
            memory_path=self._config.memory_path,
            system_prompt=self._config.system_prompt,
            nodes=self._config.nodes,
            save_config=self._persist_config,
        )
        await self._agent.start()

        # Wire the confirmation gate to the web UI: deliver requests over the
        # chat WebSocket, and let the WS route resolve them.
        from dax.web.routes.chat import ws_manager

        # Confirmations carry tool arguments and authorize a side effect, so
        # they go only to the client that owns the conversation — never to
        # every attached client.
        self._approval.set_notifier(ws_manager.deliver_approval)

        # Stream agent events (tool calls, thinking) to the web UI in real time.
        async def _broadcast_event(event: dict[str, Any]) -> None:
            frame = {"type": "agent_event", "event": event}
            session_id = event.get("session_id")
            if isinstance(session_id, str) and session_id:
                frame["session_id"] = session_id
            await ws_manager.dispatch(frame)

        self._agent.set_event_broadcaster(_broadcast_event)
        if hasattr(self._web_app, "state"):
            self._web_app.state.approval = self._approval
        log.info("Agent ready")

        # 7. Dispatcher (routes outbound messages to ALL channels)
        self._dispatcher = Dispatcher(
            bus=self._bus,
            channels=self._channels,  # type: ignore[arg-type]
        )
        await self._dispatcher.start()
        log.info("Dispatcher ready")

        # 8. Voice pipeline (runs in dedicated thread, needs the event loop)
        if self._config.voice.enabled and "voice" in self._channels:
            try:
                from dax.voice.pipeline import VoicePipeline

                loop = asyncio.get_running_loop()
                voice_ch = self._channels["voice"]
                assert isinstance(voice_ch, VoiceChannel)

                self._voice_pipeline = VoicePipeline(
                    config=self._config.voice,
                    bus=self._bus,
                    voice_channel=voice_ch,
                    loop=loop,
                    models_path=self._config.storage.models_path,
                    approval=self._approval,
                    events=self._voice_events,
                    tts_service=self._tts_service,
                )
                self._voice_pipeline.start()
                if hasattr(self._web_app, "state"):
                    self._web_app.state.voice_pipeline = self._voice_pipeline
                    self._web_app.state.voice_listening = True
                # Lets laptops with a microphone claim the wake word against
                # this host's own, so whichever is nearest the user answers.
                if self._capability_hub is not None:
                    self._capability_hub.set_pipeline(self._voice_pipeline)
                log.info("Voice pipeline ready")
            except Exception:
                log.exception("Voice pipeline failed to start — continuing without voice")
                self._voice_pipeline = None
                if hasattr(self._web_app, "state"):
                    self._web_app.state.voice_pipeline = None
                    self._web_app.state.voice_listening = False
                if self._capability_hub is not None:
                    self._capability_hub.set_pipeline(None)

        self._web_app.state.ready = True
        log.info("Dax Assistant is ready")

    async def reload_telegram(self) -> None:
        """Restart the Telegram channel to apply config changes without a full
        app restart. Stops any running channel, then starts a fresh one when
        enabled. Safe to call when Telegram is disabled (just tears down)."""
        # The dispatcher shares this exact dict reference, so mutating it in
        # place is enough — routing picks up the change immediately.
        existing = self._channels.pop("telegram", None)
        if existing is not None:
            await existing.stop()

        if self._config.telegram.enabled and self._config.telegram.bot_token:
            tg_channel = TelegramChannel(self._config.telegram, self._bus)
            await tg_channel.start()
            self._channels["telegram"] = tg_channel
            logger.info("Telegram channel reloaded")

    async def reload_voice(self) -> None:
        """Serialize live voice reloads so repeated UI saves remain safe."""
        async with self._voice_reload_lock:
            await self._reload_voice_now()

    async def _reload_voice_now(self) -> None:
        """Restart the voice channel and pipeline with the live configuration."""
        from dax.voice.pipeline import VoicePipeline as VoicePipelineImpl

        old_tts_service = self._tts_service

        if self._capability_hub is not None:
            self._capability_hub.set_pipeline(None)
        if self._voice_pipeline is not None:
            await asyncio.to_thread(self._voice_pipeline.stop)
            self._voice_pipeline = None
        else:
            await asyncio.to_thread(old_tts_service.stop)

        existing = self._channels.pop("voice", None)
        if existing is not None:
            await existing.stop()

        self._web_app.state.voice_pipeline = None
        self._web_app.state.voice_listening = False
        if not self._config.voice.enabled:
            self._tts_service = TTSService(
                self._config.voice, self._config.storage.models_path
            )
            self._web_app.state.tts_service = self._tts_service
            logger.info("Voice pipeline disabled")
            return

        voice_channel = VoiceChannel()
        await voice_channel.start()
        self._channels["voice"] = voice_channel
        self._tts_service = TTSService(self._config.voice, self._config.storage.models_path)
        self._web_app.state.tts_service = self._tts_service
        try:
            self._voice_pipeline = VoicePipelineImpl(
                config=self._config.voice,
                bus=self._bus,
                voice_channel=voice_channel,
                loop=asyncio.get_running_loop(),
                models_path=self._config.storage.models_path,
                approval=self._approval,
                events=self._voice_events,
                tts_service=self._tts_service,
            )
            await asyncio.to_thread(self._voice_pipeline.start)
        except Exception:
            self._channels.pop("voice", None)
            await voice_channel.stop()
            self._voice_pipeline = None
            if self._capability_hub is not None:
                self._capability_hub.set_pipeline(None)
            raise

        self._web_app.state.voice_pipeline = self._voice_pipeline
        self._web_app.state.voice_listening = True
        if self._capability_hub is not None:
            self._capability_hub.set_pipeline(self._voice_pipeline)
        logger.info(
            "Voice pipeline reloaded (stt_backend=%s)",
            self._config.voice.stt_backend,
        )

    async def stop(self) -> None:
        """Shut down all components in reverse order."""
        log = logger.bind(app="dax")
        log.info("Shutting down Dax Assistant")
        self._web_app.state.ready = False

        if self._uvicorn_server:
            self._uvicorn_server.should_exit = True

        # Voice pipeline first (it's in a thread)
        if self._voice_pipeline:
            self._voice_pipeline.stop()
        else:
            self._tts_service.stop()

        if self._dispatcher:
            await self._dispatcher.stop()
        if self._agent:
            await self._agent.stop()

        for _name, channel in self._channels.items():
            await channel.stop()

        if self._capability_hub is not None:
            await self._capability_hub.stop()
        await self._mcp.stop()
        await self._database.stop()

        log.info("Dax Assistant stopped")

    async def run(self) -> None:
        """Run the application with embedded uvicorn server."""
        loop = asyncio.get_running_loop()

        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, self._request_shutdown)

        await self.start()

        # Run uvicorn embedded in the same event loop
        uvicorn_config = uvicorn.Config(
            app=self._web_app,
            host=self._config.web.effective_host,
            port=self._config.web.port,
            log_level=self._config.log_level.lower(),
            access_log=False,
        )
        self._uvicorn_server = uvicorn.Server(uvicorn_config)

        try:
            await self._uvicorn_server.serve()
        finally:
            await self._stop_even_if_cancelled()

    async def _stop_even_if_cancelled(self) -> None:
        """Run shutdown to completion even if uvicorn/request cancellation leaks."""
        task = asyncio.create_task(self.stop(), name="dax-shutdown")
        while not task.done():
            try:
                await asyncio.shield(task)
            except asyncio.CancelledError:
                current = asyncio.current_task()
                if current is not None:
                    current.uncancel()
        await task

    def _request_shutdown(self) -> None:
        """Signal handler — request graceful shutdown."""
        self._shutdown_event.set()
        if self._uvicorn_server:
            self._uvicorn_server.should_exit = True
