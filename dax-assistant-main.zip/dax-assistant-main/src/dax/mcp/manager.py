"""MCP server manager — implements the ToolProvider protocol.

Manages the lifecycle of multiple MCP server connections (both local
stdio and remote HTTP), aggregates tools, and routes execution.

Supports environment variable substitution in config values using
{env:VAR_NAME} syntax for secure credential management.
"""

from __future__ import annotations

import asyncio
import logging
import os
import re
from typing import TYPE_CHECKING, Any

from dax.core.exceptions import ToolNotFoundError
from dax.core.models import ToolCall, ToolResult
from dax.mcp.client import MCPClient
from dax.mcp.registry import ToolRegistry

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from dax.core.config import MCPConfig, MCPServerConfig

logger = logging.getLogger(__name__)

# Pattern for {env:VAR_NAME} substitution
_ENV_PATTERN = re.compile(r"\{env:(\w+)\}")


def _resolve_env_vars(value: str, variables: dict[str, str] | None = None) -> str:
    """Replace {env:VAR_NAME} patterns with environment variable values."""

    lookup = {**os.environ, **(variables or {})}

    def _replace(match: re.Match[str]) -> str:
        var_name = match.group(1)
        env_value = lookup.get(var_name, "")
        if not env_value:
            logger.warning("Environment variable '%s' not set", var_name)
        return env_value

    return _ENV_PATTERN.sub(_replace, value)


def _resolve_env_dict(
    d: dict[str, str], variables: dict[str, str] | None = None
) -> dict[str, str]:
    """Resolve env vars in all values of a dict."""
    return {k: _resolve_env_vars(v, variables) for k, v in d.items()}


# Desktop/session variables a *local* stdio server (the bundled dax-system)
# needs to actually drive the user's machine: launch GUI apps, open files via
# xdg-open, send notify-send notifications. The MCP SDK otherwise strips a
# spawned subprocess down to a minimal env (HOME/PATH/SHELL/…), so a GUI app
# would start with no display/bus to attach to — the classic "process is
# running but no window appears". We pass these through from the dax process's
# own environment when present (harmless for non-GUI servers).
_SESSION_PASSTHROUGH_VARS = (
    "DISPLAY",
    "WAYLAND_DISPLAY",
    "XAUTHORITY",
    "XDG_RUNTIME_DIR",
    "XDG_SESSION_TYPE",
    "XDG_SESSION_CLASS",
    "XDG_CURRENT_DESKTOP",
    "XDG_DATA_DIRS",
    "XDG_CONFIG_DIRS",
    "DBUS_SESSION_BUS_ADDRESS",
    "DESKTOP_SESSION",
)


def _session_passthrough_env() -> dict[str, str]:
    """Snapshot desktop-session vars present in the current environment."""
    return {
        var: os.environ[var]
        for var in _SESSION_PASSTHROUGH_VARS
        if os.environ.get(var)
    }


def _get_oauth_token(server_name: str) -> str | None:
    """Get stored OAuth access token for an MCP server, if available."""
    try:
        from dax.web.routes.oauth import get_access_token
        return get_access_token(server_name)
    except Exception:
        return None


class MCPManager:
    """Manages multiple MCP server connections.

    Implements the ToolProvider protocol. Supports:
    - **stdio** transport: spawns local subprocess (npx, uvx, etc.)
    - **streamable_http** transport: connects to remote HTTP MCP server

    Config values support {env:VAR_NAME} for secure credential injection.
    """

    def __init__(self, config: MCPConfig) -> None:
        self._config = config
        self._clients: dict[str, MCPClient] = {}
        self._dynamic_executors: dict[
            str, Callable[[ToolCall], Awaitable[ToolResult]]
        ] = {}
        self._registry = ToolRegistry()
        self._lock = asyncio.Lock()
        self._stopping = False
        self._ops: asyncio.Queue[
            tuple[
                str,
                str | None,
                MCPServerConfig | None,
                asyncio.Future[int | None],
            ]
        ] | None = None
        self._worker: asyncio.Task[None] | None = None

    @property
    def registry(self) -> ToolRegistry:
        return self._registry

    def _make_client(
        self, name: str, server_config: MCPServerConfig
    ) -> MCPClient | None:
        """Build an unconnected client for a server config (env resolved)."""
        transport = server_config.transport

        if transport == "stdio":
            if not server_config.command:
                logger.warning("MCP server '%s' (stdio) has no command, skipping", name)
                return None
            # Session vars first so an explicitly configured server env wins.
            return MCPClient(
                server_name=name,
                command=server_config.command,
                args=server_config.args,
                env={
                    **_session_passthrough_env(),
                    **_resolve_env_dict(server_config.env),
                },
            )

        if transport in ("streamable_http", "sse", "http"):
            if not server_config.url:
                logger.warning(
                    "MCP server '%s' (%s) has no URL, skipping", name, transport
                )
                return None
            # HTTP servers can define credentials in their own env field.  Use
            # those values when resolving header placeholders, while still
            # allowing references to the Dax process environment.
            server_env = _resolve_env_dict(server_config.env)
            headers = _resolve_env_dict(server_config.headers, server_env)
            oauth_token = _get_oauth_token(name)
            if oauth_token:
                headers["Authorization"] = f"Bearer {oauth_token}"
            return MCPClient(
                server_name=name,
                transport="http",
                url=_resolve_env_vars(server_config.url),
                headers=headers,
            )

        logger.warning(
            "MCP server '%s' has unknown transport '%s', skipping", name, transport
        )
        return None

    async def start(self) -> None:
        """Launch and connect to all enabled MCP servers."""
        self._stopping = False
        self._ensure_worker()
        for name, server_config in self._config.servers.items():
            if not server_config.enabled:
                logger.info("MCP server '%s' is disabled, skipping", name)
                continue
            try:
                await self.add_server(name, server_config)
            except (KeyboardInterrupt, SystemExit):
                raise
            except BaseException:
                # BaseException (not just Exception) because anyio/MCP SDK can
                # propagate CancelledError (a BaseException in Python 3.11)
                # when HTTP transport connection fails.
                logger.exception("Failed to start MCP server '%s'", name)

        logger.info(
            "MCP Manager started: %d servers, %d total tools",
            len(self._clients),
            self._registry.tool_count,
        )

    async def add_server(self, name: str, server_config: MCPServerConfig) -> int:
        """Connect to a server and register its tools live. Returns tool count.

        Reconnects cleanly if the server was already connected. Raises on
        connection failure so callers can surface the error.
        """
        result = await self._submit("add", name, server_config)
        if result is None:
            raise RuntimeError("MCP add operation returned no tool count")
        return result

    async def _add_server_now(self, name: str, server_config: MCPServerConfig) -> int:
        if self._stopping:
            raise RuntimeError("MCP manager is stopping")

        await self._remove_server_now(name)

        # Best-effort: refresh an expired OAuth token before (re)connecting an
        # HTTP server so the new Bearer header carries a valid token.
        if getattr(server_config, "transport", "stdio") in (
            "streamable_http", "sse", "http"
        ):
            try:
                from dax.web.routes.oauth import refresh_access_token

                await refresh_access_token(name)
            except Exception:
                logger.debug("Token refresh skipped for '%s'", name, exc_info=True)

        client = self._make_client(name, server_config)
        if client is None:
            raise ValueError(f"MCP server '{name}' has an invalid configuration")

        try:
            await client.connect()
            tools = await client.list_tools()
        except BaseException:
            await client.disconnect()
            raise

        self._clients[name] = client
        self._registry.register(tools)
        logger.info(
            "MCP server '%s' (%s) ready with %d tools",
            name, server_config.transport, len(tools),
        )
        return len(tools)

    async def remove_server(self, name: str) -> None:
        """Disconnect a server (if connected) and drop its tools."""
        await self._submit("remove", name, None)

    async def _remove_server_now(self, name: str) -> None:
        """Disconnect a server from the MCP lifecycle worker task."""
        client = self._clients.pop(name, None)
        if client is not None:
            try:
                await client.disconnect()
            except Exception:
                logger.exception("Error disconnecting MCP server '%s'", name)
        self._registry.unregister_server(name)

    async def stop(self) -> None:
        """Disconnect from all MCP servers."""
        self._stopping = True
        if self._worker is not None and not self._worker.done():
            await self._submit("stop", None, None)
            await self._worker
            self._worker = None
            self._ops = None
            return

        await self._stop_now()

    async def _stop_now(self) -> None:
        clients = list(self._clients.items())
        self._clients.clear()
        self._dynamic_executors.clear()
        self._registry.clear()

        for name, client in clients:
            try:
                await client.disconnect()
            except Exception:
                logger.exception("Error disconnecting MCP server '%s'", name)

        logger.info("MCP Manager stopped")

    def _ensure_worker(self) -> None:
        if self._worker is None or self._worker.done():
            self._ops = asyncio.Queue()
            self._worker = asyncio.create_task(
                self._run_lifecycle_worker(),
                name="mcp-lifecycle-worker",
            )

    async def _submit(
        self,
        op: str,
        name: str | None,
        payload: MCPServerConfig | None,
    ) -> int | None:
        self._ensure_worker()
        assert self._ops is not None
        loop = asyncio.get_running_loop()
        future: asyncio.Future[int | None] = loop.create_future()
        await self._ops.put((op, name, payload, future))
        return await future

    async def _run_lifecycle_worker(self) -> None:
        assert self._ops is not None
        while True:
            op, name, payload, future = await self._ops.get()
            try:
                result: int | None
                if op == "add":
                    assert name is not None
                    assert payload is not None
                    result = await self._add_server_now(name, payload)
                elif op == "remove":
                    assert name is not None
                    await self._remove_server_now(name)
                    result = None
                elif op == "stop":
                    await self._stop_now()
                    result = None
                    if not future.done():
                        future.set_result(result)
                    break
                else:
                    raise RuntimeError(f"Unknown MCP lifecycle op: {op}")
            except BaseException as exc:
                if not future.done():
                    future.set_exception(exc)
            else:
                if not future.done():
                    future.set_result(result)

    def server_status(self) -> list[dict[str, Any]]:
        """Per-configured-server connection + tool status for the web UI."""
        lookup = self._registry.server_lookup
        statuses: list[dict[str, Any]] = []
        for name, cfg in self._config.servers.items():
            client = self._clients.get(name)
            tools = sorted(t for t, s in lookup.items() if s == name)
            statuses.append(
                {
                    "name": name,
                    "connected": client is not None and client.is_connected,
                    "transport": cfg.transport,
                    "enabled": cfg.enabled,
                    "tool_count": len(tools),
                    "tools": tools,
                }
            )
        return statuses

    def register_dynamic_provider(
        self,
        server_name: str,
        tools: list[dict[str, Any]],
        executor: Callable[[ToolCall], Awaitable[ToolResult]],
    ) -> None:
        """Atomically install an ephemeral, non-configured tool provider."""
        if not server_name.startswith("capability-node:"):
            raise ValueError("Dynamic provider name is not reserved")
        if server_name in self._clients:
            raise ValueError("Dynamic provider collides with a configured server")
        self._registry.replace_server(server_name, tools, reject_collisions=True)
        self._dynamic_executors[server_name] = executor

    def unregister_dynamic_provider(self, server_name: str) -> None:
        """Remove tools before future calls can resolve to this provider."""
        self._registry.unregister_server(server_name)
        self._dynamic_executors.pop(server_name, None)

    async def list_tools(self) -> list[dict[str, Any]]:
        """Return all available tool schemas across all servers."""
        return self._registry.all_tools

    def get_relevant_tools(
        self, query: str, max_tools: int
    ) -> list[dict[str, Any]]:
        """Return the tools most relevant to ``query`` (ToolProvider port).

        Delegates to the registry's keyword-relevance filter; ``dax-system``
        tools are always included there. Keeps the agent decoupled from the
        registry implementation.
        """
        return self._registry.get_relevant_tools(query, max_tools=max_tools)

    def get_server_for_tool(self, tool_name: str) -> str | None:
        """Return which server owns ``tool_name`` (ToolProvider port)."""
        return self._registry.get_server_for_tool(tool_name)

    async def execute(self, tool_call: ToolCall) -> ToolResult:
        """Execute a tool call on the appropriate MCP server."""
        server_name = tool_call.server_name
        if not server_name or server_name == "":
            server_name = (
                self._registry.get_server_for_tool(tool_call.tool_name) or ""
            )

        if not server_name:
            raise ToolNotFoundError(
                f"No server found for tool '{tool_call.tool_name}'"
            )

        dynamic = self._dynamic_executors.get(server_name)
        if dynamic is not None:
            # Approval and execution can be separated by an inventory replacement.
            # Revalidate the exact live owner immediately before dispatching.
            if self._registry.get_server_for_tool(tool_call.tool_name) != server_name:
                raise ToolNotFoundError(
                    f"Tool '{tool_call.tool_name}' is no longer provided by "
                    f"MCP server '{server_name}'"
                )
            resolved_call = ToolCall(
                id=tool_call.id,
                server_name=server_name,
                tool_name=tool_call.tool_name,
                arguments=tool_call.arguments,
                # Carried, not defaulted: a capability node enforces its own
                # allowlist and refuses anything it cannot see was approved, so
                # dropping this here makes the confirmation modal do nothing.
                human_approved=tool_call.human_approved,
            )
            return await dynamic(resolved_call)

        client = self._clients.get(server_name)
        if client is None:
            raise ToolNotFoundError(
                f"MCP server '{server_name}' is not connected"
            )

        logger.info(
            "Executing tool '%s' on server '%s'",
            tool_call.tool_name, server_name,
        )

        resolved_call = ToolCall(
            id=tool_call.id,
            server_name=server_name,
            tool_name=tool_call.tool_name,
            arguments=tool_call.arguments,
            human_approved=tool_call.human_approved,
        )

        return await client.execute(resolved_call)
