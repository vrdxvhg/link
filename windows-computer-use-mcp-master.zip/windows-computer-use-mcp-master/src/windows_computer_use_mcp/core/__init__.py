"""PyWinAuto MCP core package."""
